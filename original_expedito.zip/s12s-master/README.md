
# How to

Arquivos .env.* contém variáveis de configuração para respectivo ambiente.
Arquivo docker-compose.yml contém configuração usada pelo docker.



## Deploy local

### Update /etc/hosts

```
# BEGIN STANDUP EXPRESS
127.0.0.1        fotoland.local
127.0.0.1    up3.fotoland.local
127.0.0.1    img.fotoland.local
127.0.0.1 status.fotoland.local
# END STANDUP EXPRESS
```

### Comandos

```
git clone git@github.com:expedit85/s12s.git path/to/src
cd path/to/src
infra/deploy up dev     # usa variáveis em .env.dev

```

Comando `infra/deploy up ...` pode ser executado seguidas vezes se necessário (ex. algum arquivo modificado e não atualizado no container). Arquivos da pasta web/ são atualizados ao salvar (variável WEB_DIR do .env.*)

Um certificado para uma pseudo autoridade certificadora será criado em `.data/ssl/certs/ca.pem`, adicione-o no browser: chrome://settings/certificates > Auhtorities > Import, escolha o arquivo de certificado e marque-o para websites. Em seguida navegue para https://fotoland.local/.



## Deploy no servidor

No terminal local, digite `infra/ssh` para entrar no terminal do servidor (infra/id_rsa precisar existir).

No servidor: `cd ~/src/s12s/ && git restore web/src/image.html && git pull origin && infra/deploy.sh up prod`

O certificado HTTPS é gerado automaticamente via Let's Encrypt.

Para evitar criação de mais um servidor, a pasta indicada na variável IMG_DIR, contém as subpastas dev e prod. A primeira (dev) contém arquivos gerados via ambiente de dev do Wix (my-site-1 ou equivalente), a segunda (prod) arquivos gerados no ambiente de prod do Wix (associado com domínio do site).


## ...

https://hmorize.wixsite.com/my-site-3
https://manage.wix.com/dashboard
https://manage.wix.com/ > My Site 1 > Edit Site
https://wix.com/velo/reference

