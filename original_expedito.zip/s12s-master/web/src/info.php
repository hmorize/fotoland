<?
// require 'sku.php';
// $a = sku_create(100, 600, 'W', 'expedito');
// $a = size_encode(327, 999);
// $a = size_decode('031x923');
// echo json_encode($a)
phpinfo();
?>
