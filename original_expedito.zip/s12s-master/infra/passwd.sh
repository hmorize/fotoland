#!/bin/bash

for u in "$@" ; do openssl rand -base64 6 | tee /dev/stderr | htpasswd -ni $u | tee -a proxy/files/etc/nginx/.htpasswd1; done
