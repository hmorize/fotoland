#!/bin/bash

usage() {
	cat <<-EOF
	$0  up   TARGET
	$0  down TARGET
	EOF
}

#   exit-code  message...
fail() {
	local ret
	ret=$1
	shift
	echo "$@" >&2
	exit $ret
}


WWW_UID=33


deploy() {
	local target
	test $# -eq 1 || fail 1 "target required"
	target="$1"

	ln -s .env.$target .env
	source .env &&
	mkdir -p "${IMG_DIR}" \
	         "${LOG_DIR}"/{nginx,php} \
	         "${SSL_DIR}"/{getssl,certs,acme-challenge} \
	         "${SECRETS_DIR}"
	touch "${LOG_DIR}/php/php.log"
	sudo chown -R $WWW_UID:$WWW_UID "${IMG_DIR}"

	BUILD_NUMBER=$(cat .build-number || echo 0)
	BUILD_NUMBER=$((${BUILD_NUMBER:0}+1))
	echo $BUILD_NUMBER > .build-number

	export BUILD_NUMBER="$(printf "%03d" $BUILD_NUMBER)"
	export VERSION=$(git describe)
	
	sed -i -r 's~<span id="version">v[0-9a-z.-]+</span>~<span id="version">v'"${VERSION}-${BUILD_NUMBER}"'</span>~' "${WEB_DIR}/image.html" &&
	docker-compose config > stack-config.yml &&
	docker-compose build &&
	docker stack deploy -c stack-config.yml s12s
}


down() {
	docker stack rm s12s
}

# set -x  # show command before executing

case "$1" in
	up)
		shift
		deploy "$@"
		;;
	down)
		shift
		down "$@"
		;;
	*)
		echo invalid command
		echo
		usage
		;;
esac
