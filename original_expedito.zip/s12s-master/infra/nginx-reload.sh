#!/bin/bash

docker exec -ti $(docker ps -q --filter name=proxy) nginx -s reload
